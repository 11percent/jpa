package com.took.jpa.social;

public interface SocialUserInfo {
    public String getProviderId();
    public String getProvider();
    public String getEmail();
    public String getName();
}
